CKEDITOR.plugins.setLang("pbckcode","en",
{
	title: 'Add code',
	addCode : 'Add code',
	editCode : 'Edit code'
});